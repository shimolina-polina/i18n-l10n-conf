export const LANG_COOKIE_NAME = "i18n-l10n-conf-lang";
