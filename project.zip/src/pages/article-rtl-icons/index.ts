export { ArticleRtlIcons } from "./ArticleRtlIcons";
