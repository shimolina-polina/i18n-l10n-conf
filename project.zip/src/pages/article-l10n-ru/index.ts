export { ArticleL10nRu } from "./ArticleL10nRu";
