export { ArticleAr } from "./ArticleAr";
